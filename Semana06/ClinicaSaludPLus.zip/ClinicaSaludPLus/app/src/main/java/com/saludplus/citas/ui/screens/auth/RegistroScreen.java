package com.saludplus.citas.ui.screens.auth;

public class RegistroScreen {
}
